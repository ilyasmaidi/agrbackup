<?php
include('../config/dbcon.php');

function GetAll($table){
    global $con;
    $query = "SELECT * FROM $table";
    return $query_run = mysqli_query($con, $query);
}

function GetByID($table, $id){
    global $con;
    $query = "SELECT * FROM $table WHERE id='$id'";
    return $query_run = mysqli_query($con, $query);
}

function redirect($message, $url){
    ob_start(); // بداية تخزين الإخراج
    $_SESSION['message'] = $message;
    header('Location: '.$url);
    ob_end_flush(); // تفريغ الذاكرة المؤقتة للإخراج وإرساله
    exit();
}
?>
