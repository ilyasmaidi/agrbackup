<?php include('./includes/start.php');?>
<?php include('./includes/register.php');?>
<?php include('./includes/end.php');?>