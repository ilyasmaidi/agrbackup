<!-- <?php 
$main_banner_query = "SELECT * FROM edit (name,slug,description)VALUES ($name,$slug,$description)";

?> -->


<div class="main-banner">
            <div class="main-banner-item banner-item-two">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="main-banner-content">
                                        <span>agritech Solutions</span>
                                        <h1>We're not waiting for the opportunity, we're planting it.</h1>
                                        <div class="banner-btn">
                                            <a href="shop.php" class="default-btn">Our Shop</a>
                                            <a href="cart.php" class="optional-btn">Add to Cart</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="main-banner-image">
                                        <img src="assets/img/banner-woman.png" alt="image">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="main-banner-shape">
                <div class="shape-1">
                    <img src="assets/img/banner-shape/banner-shape-1.png" alt="image">
                </div>
            </div>
        </div>