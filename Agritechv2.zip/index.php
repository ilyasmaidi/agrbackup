<?php 
session_start();
include('./includes/start.php');
?>
<?php include('./includes/index.php');?>
<?php include('./includes/end.php');?>