<?php include('./includes/start.php');?>
<?php include('./includes/shop.php');?>
<?php include('./includes/end.php');?>