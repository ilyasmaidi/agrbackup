<section id="sidebar" class="fixed-sidebar">
		<a href="#" class="brand"><i class='bx bxs-smile icon'></i>Agri Tech</a>
		<ul class="side-menu">
			<li><a href="#" class="active"><i class='bx bxs-dashboard icon' ></i> Dashboard</a></li>
			<li class="divider" data-text="main">Main</li>
			<li>
				<a href="#"><i class='bx bxs-inbox icon' ></i> Elements <i class='bx bx-chevron-right icon-right' ></i></a>
				<ul class="side-dropdown Show">
					<li><a href="edit-home_admin.php">Edit Hero</a></li>
					<li><a href="banner_admin.php">Banner</a></li>
					<li><a href="key-principles_admin.php">Key Princibles</a></li>
					<li><a href="choose_admin.php">Choose Section</a></li>
					<li><a href="youtube.php">Video Section</a></li>
					<li><a href="ourservices.php">Services Section</a></li>
					<li><a href="smart.php">Smart Farm Section</a></li>
				</ul>
			</li>
			<li><a href="#"><i class='bx bxs-chart icon' ></i> Charts</a></li>
			<li><a href="#"><i class='bx bxs-widget icon' ></i> Widgets</a></li>
			<li class="divider" data-text="table and forms">Table and forms</li>
			<li><a href="#"><i class='bx bx-table icon' ></i> Tables</a></li>
			<li>
				<a href="#"><i class='bx bxs-notepad icon' ></i> Forms <i class='bx bx-chevron-right icon-right' ></i></a>
				<ul class="side-dropdown">
					<li><a href="#">Basic</a></li>
					<li><a href="#">Select</a></li>
					<li><a href="#">Checkbox</a></li>
					<li><a href="#">Radio</a></li>
				</ul>
			</li>
		</ul>
		<div class="ads">
			<div class="wrapper">
				<a href="logout.php" class="btn-upgrade">Logout</a>
				<p>This a <span>PRO</span> member and enjoy <span>All Features MediaKing</span></p>
			</div>
		</div>
	</section>