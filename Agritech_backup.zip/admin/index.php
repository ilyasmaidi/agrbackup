<?php include("./includes/start_admin.php");?>

	
	<!-- SIDEBAR -->
	<?php include("./includes/sidebar_admin.php");?>

	<!-- SIDEBAR -->

	<!-- NAVBAR -->
	<section id="content">
		<!-- NAVBAR -->
	    <?php include("./includes/navbar_admin.php");?>
		
		<!-- NAVBAR -->

		<!-- MAIN -->
        <?php include("./includes/main_admin.php");?>

		<!-- MAIN -->
	</section>
	<!-- NAVBAR -->

	<?php include("./includes/end_admin.php");?>