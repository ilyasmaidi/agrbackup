<?php include('./includes/start.php');?>
<?php include('./includes/contact.php');?>
<?php include('./includes/end.php');?>