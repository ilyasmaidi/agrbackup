<section class="food-area pb-70">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="food-item">
                            <div class="food-image">
                                <img src="assets/img/food/food-1.png" alt="image">
                            </div>
                            <div class="food-content">
                                <h3>Complete control</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="food-item">
                            <div class="food-image">
                                <img src="assets/img/food/food-2.png" alt="image">
                            </div>
                            <div class="food-content">
                                <h3 id="aboutus">Smart platform</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 offset-lg-0 offset-md-3">
                        <div class="food-item">
                            <div class="food-image">
                                <img src="assets/img/food/food-3.png" alt="image">
                            </div>
                            <div class="food-content">
                                <h3>Real-time reports</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>